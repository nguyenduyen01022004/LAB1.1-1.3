﻿using System;
using System.Text;
namespace LAB01
{
    class Program
    {
        static void Main(string[] args)
        {
            //Config Console Output được Tiếng Việt
            Console.OutputEncoding = Encoding.UTF8;
            //1. Khai báo biến
            int x1, x2, y1, y2;
            //2. Nhập giá trị
            Console.WriteLine("Nhập điểm A(x1, y1):");
            Console.Write("- x1: ");
            x1 = int.Parse(Console.ReadLine());
            Console.Write("- y1: ");
            y1 = int.Parse(Console.ReadLine());
            Console.WriteLine("Nhập điểm B(x2, y2):");
            Console.Write("- x2: ");
            x2 = int.Parse(Console.ReadLine());
            Console.Write("- y2: ");
            y2 = int.Parse(Console.ReadLine());
            //3. Tính khoảng cách
            double khoangCach = Math.Sqrt(Math.Pow(x2 - x1, 2) + Math.Pow(y2 - y1, 2));
            //4. Hiển thị kết quả
            Console.WriteLine($"Khoảng cách giữa điểm A({x1}, {y1}) với điểm B({x2}, {y2}) = {khoangCach}");


            /* Bài 1: Viết chương trình nhập vào tên và tuổi, sau đó in ra màn hình thông báo
            "Xin chào[tên], bạn[tuổi] tuổi!"*/

            // Khai báo biến  
            string name;
            int age;
            // Nhập tên  
            Console.Write("Nhập tên của bạn: ");
            name = Console.ReadLine();
            // Nhập tuổi  
            Console.Write("Nhập tuổi của bạn: ");
            age = int.Parse(Console.ReadLine());
            // In ra thông báo chào hỏi  
            Console.WriteLine($"Xin chào {name}, bạn {age} tuổi!");

            // Bài 2: Viết chương trình tính diện tích của hình chữ nhật khi người dùng nhập chiều dài và chiều rộng.
            // Khai báo biến
            double chieuDai, chieuRong, dienTich;
            // Nhập chiều dài
            Console.Write("Nhập chiều dài của hình chữ nhật: ");
            chieuDai = double.Parse(Console.ReadLine());
            // Nhập chiều rộng
            Console.Write("Nhập chiều rộng của hình chữ nhật: ");
            chieuRong = double.Parse(Console.ReadLine());
            // Tính diện tích
            dienTich = chieuDai * chieuRong;
            // In ra diện tích
            Console.WriteLine($"Diện tích của hình chữ nhật là: {dienTich}");


            // Bài 3: Viết chương trình chuyển đổi nhiệt độ từ độ C sang độ F
            // Khai báo biến
            double doC, doF;
            // Nhập nhiệt độ độ C
            Console.Write("Nhập nhiệt độ độ C: ");
            doC = double.Parse(Console.ReadLine());
            // Chuyển đổi sang độ F
            doF = (doC * 9 / 5) + 32;
            // In ra nhiệt độ độ F
            Console.WriteLine($"Nhiệt độ độ F là: {doF}");


            // Bài 4: Viết chương trình nhập vào một số nguyên và kiểm tra xem số đó có phải là số chẵn hay không.
            // Khai báo biến
            int soNguyen;
            // Nhập số nguyên
            Console.Write("Nhập một số nguyên: ");
            soNguyen = int.Parse(Console.ReadLine());
            // Kiểm tra số chẵn hay lẻ
            if (soNguyen % 2 == 0)
            {
                Console.WriteLine($"{soNguyen} là số chẵn.");
            }
            else
            {
                Console.WriteLine($"{soNguyen} là số lẻ.");
            }

            // Bài 5: Viết chương trình tính tổng và tích của hai số nhập từ bàn phím.
            // Khai báo biến
            int so1, so2, tong, tich;
            // Nhập số 1
            Console.Write("Nhập số thứ nhất: ");
            so1 = int.Parse(Console.ReadLine());
            // Nhập số 2
            Console.Write("Nhập số thứ hai: ");
            so2 = int.Parse(Console.ReadLine());
            // Tính tổng và tích
            tong = so1 + so2;
            tich = so1 * so2;
            // In ra kết quả
            Console.WriteLine($"Tổng của {so1} và {so2} là: {tong}");
            Console.WriteLine($"Tích của {so1} và {so2} là: {tich}");


            // Bài 6: Viết chương trình kiểm tra xem một số nhập vào có phải là số dương, số âm hay số không.
            // Khai báo biến
            int so;
            // Nhập số
            Console.Write("Nhập một số: ");
            so = int.Parse(Console.ReadLine());
            // Kiểm tra số dương, âm hay không
            if (so > 0)
            {
                Console.WriteLine($"{so} là số dương.");
            }
            else if (so < 0)
            {
                Console.WriteLine($"{so} là số âm.");
            }
            else
            {
                Console.WriteLine($"{so} là số không.");
            }


            // Bài 7: Viết chương trình kiểm tra xem một năm nhập vào có phải là năm nhuận hay không.
            // Khai báo biến
            int nam;
            // Nhập năm
            Console.Write("Nhập một năm: ");
            nam = int.Parse(Console.ReadLine());
            // Kiểm tra năm nhuận
            if ((nam % 4 == 0 && nam % 100 != 0) || (nam % 400 == 0))
            {
                Console.WriteLine($"{nam} là năm nhuận.");
            }
            else
            {
                Console.WriteLine($"{nam} không phải là năm nhuận.");
            }


            // Bài 8: Viết chương trình in ra bảng cửu chương từ 1 đến 10.
            // Khai báo biến
            int i, j;
            // In ra bảng cửu chương
            Console.WriteLine("Bảng cửu chương:");
            for (i = 1; i <= 10; i++)
            {
                for (j = 1; j <= 10; j++)
                {
                    Console.Write($"{i} x {j} = {i * j}\t");
                }
                Console.WriteLine();
            }
            // Bài 9: Viết chương trình tính giai thừa của một số nguyên dương n.
            // Khai báo biến
            int n, giaiThua = 1;
            // Nhập số nguyên dương

            Console.Write("Nhập một số nguyên dương: ");
            n = int.Parse(Console.ReadLine());
            // Tính giai thừa
            for (int k = 1; k <= n; k++)
            {
                giaiThua *= k;
            }
            // In ra giai thừa
            Console.WriteLine($"Giai thừa của {n} là: {giaiThua}");


            // Bài 10: Viết chương trình kiểm tra xem một số có phải là số nguyên tố hay không.
            // Khai báo biến
            int soNguyenTo;
            bool laNguyenTo = true;
            // Nhập số nguyên
            Console.Write("Nhập một số nguyên: ");
            soNguyenTo = int.Parse(Console.ReadLine());
            // Kiểm tra số nguyên tố
            if (soNguyenTo < 2)
            {
                laNguyenTo = false;
            }
            else
            {
                for (int m = 2; m <= Math.Sqrt(soNguyenTo); m++)
                {
                    if (soNguyenTo % m == 0)
                    {
                        laNguyenTo = false;
                        break;
                    }
                }
            }
            // In ra kết quả
            if (laNguyenTo)
            {
                Console.WriteLine($"{soNguyenTo} là số nguyên tố.");
            }
            else
            {
                Console.WriteLine($"{soNguyenTo} không phải là số nguyên tố.");
            }
        }

    }
}
