﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class SoPhuc
{
    public double PhanThuc { get; set; }
    public double PhanAo { get; set; }

    // Hàm tạo không đối số
    public SoPhuc()
    {
        PhanThuc = 0;
        PhanAo = 0;
    }

    // Hàm tạo có đối số
    public SoPhuc(double a, double b)
    {
        PhanThuc = a;
        PhanAo = b;
    }

    // Nhập số phức
    public void Nhap(string ten)
    {
        Console.WriteLine($"Nhập số phức {ten}:");
        Console.Write("Phần thực: ");
        PhanThuc = double.Parse(Console.ReadLine());
        Console.Write("Phần ảo: ");
        PhanAo = double.Parse(Console.ReadLine());
    }

    // Hiển thị số phức
    public void HienThi(string moTa = "")
    {
        if (!string.IsNullOrEmpty(moTa))
            Console.Write($"{moTa}: ");
        Console.WriteLine($"{PhanThuc} {(PhanAo >= 0 ? "+" : "-")} {Math.Abs(PhanAo)}i");
    }

    // Cộng hai số phức
    public SoPhuc Cong(SoPhuc b)
    {
        return new SoPhuc(this.PhanThuc + b.PhanThuc, this.PhanAo + b.PhanAo);
    }

    // Trừ hai số phức
    public SoPhuc Tru(SoPhuc b)
    {
        return new SoPhuc(this.PhanThuc - b.PhanThuc, this.PhanAo - b.PhanAo);
    }

    // Nhân hai số phức
    public SoPhuc Nhan(SoPhuc b)
    {
        double thuc = PhanThuc * b.PhanThuc - PhanAo * b.PhanAo;
        double ao = PhanThuc * b.PhanAo + PhanAo * b.PhanThuc;
        return new SoPhuc(thuc, ao);
    }

    // Chia hai số phức
    public SoPhuc Chia(SoPhuc b)
    {
        double mau = b.PhanThuc * b.PhanThuc + b.PhanAo * b.PhanAo;
        if (mau == 0)
            throw new DivideByZeroException("Không thể chia cho số phức có cả phần thực và phần ảo bằng 0.");

        double thuc = (PhanThuc * b.PhanThuc + PhanAo * b.PhanAo) / mau;
        double ao = (PhanAo * b.PhanThuc - PhanThuc * b.PhanAo) / mau;
        return new SoPhuc(thuc, ao);
    }
}
