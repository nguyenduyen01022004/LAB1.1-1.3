﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class PTGT
{
    public string HangSanXuat { get; set; }
    public int NamSanXuat { get; set; }
    public double GiaBan { get; set; }
    public string Mau { get; set; }

    public virtual void Nhap()
    {
        Console.Write("Nhập hãng sản xuất: ");
        HangSanXuat = Console.ReadLine();
        Console.Write("Nhập năm sản xuất: ");
        NamSanXuat = int.Parse(Console.ReadLine());
        Console.Write("Nhập giá bán: ");
        GiaBan = double.Parse(Console.ReadLine());
        Console.Write("Nhập màu: ");
        Mau = Console.ReadLine();
    }

    public virtual void HienThi()
    {
        Console.WriteLine($"Hãng SX: {HangSanXuat}, Năm: {NamSanXuat}, Giá: {GiaBan}, Màu: {Mau}");
    }
}

public class OTo : PTGT
{
    public int SoChoNgoi { get; set; }
    public string KieuDongCo { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhập số chỗ ngồi: ");
        SoChoNgoi = int.Parse(Console.ReadLine());
        Console.Write("Nhập kiểu động cơ: ");
        KieuDongCo = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Loại: Ô tô - Số chỗ: {SoChoNgoi}, Động cơ: {KieuDongCo}");
    }
}

public class XeMay : PTGT
{
    public double CongSuat { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhập công suất: ");
        CongSuat = double.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Loại: Xe máy - Công suất: {CongSuat} mã lực");
    }
}

public class XeTai : PTGT
{
    public double TrongTai { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhập trọng tải: ");
        TrongTai = double.Parse(Console.ReadLine());
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Loại: Xe tải - Trọng tải: {TrongTai} tấn");
    }
}

