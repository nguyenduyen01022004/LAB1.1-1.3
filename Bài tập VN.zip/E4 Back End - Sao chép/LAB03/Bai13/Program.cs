﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QLPTGT ql = new QLPTGT();
        int chon;

        do
        {
            Console.WriteLine("\n--- MENU QUẢN LÝ PHƯƠNG TIỆN GIAO THÔNG ---");
            Console.WriteLine("1. Đăng ký phương tiện");
            Console.WriteLine("2. Hiển thị danh sách phương tiện");
            Console.WriteLine("3. Tìm theo màu");
            Console.WriteLine("4. Tìm theo năm sản xuất");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn chức năng: ");
            chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1:
                    ql.NhapPT();
                    break;
                case 2:
                    ql.HienThiDanhSach();
                    break;
                case 3:
                    ql.TimTheoMau();
                    break;
                case 4:
                    ql.TimTheoNam();
                    break;
                case 0:
                    Console.WriteLine("Kết thúc chương trình.");
                    break;
                default:
                    Console.WriteLine("Chức năng không hợp lệ!");
                    break;
            }
        } while (chon != 0);
    }
}
