﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Diem
{
    public double X { get; set; }
    public double Y { get; set; }

    public Diem() { }

    public Diem(double x, double y)
    {
        X = x;
        Y = y;
    }

    public void Nhap()
    {
        Console.Write("  Nhập hoành độ (x): ");
        X = double.Parse(Console.ReadLine());
        Console.Write("  Nhập tung độ (y): ");
        Y = double.Parse(Console.ReadLine());
    }

    public void HienThi()
    {
        Console.Write($"({X}, {Y})");
    }

    public double TinhKhoangCach(Diem d2)
    {
        return Math.Sqrt(Math.Pow(X - d2.X, 2) + Math.Pow(Y - d2.Y, 2));
    }
}

