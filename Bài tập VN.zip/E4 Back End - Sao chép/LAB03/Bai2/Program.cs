﻿class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Quanly ql = new Quanly();

        while (true)
        {
            Console.WriteLine("\n--- QUẢN LÝ TÀI LIỆU ---");
            Console.WriteLine("1. Thêm tài liệu");
            Console.WriteLine("2. Hiển thị tất cả");
            Console.WriteLine("3. Tìm kiếm theo mã");
            Console.WriteLine("4. Thoát");
            Console.Write("Chọn: ");
            int chon = int.Parse(Console.ReadLine());

            switch (chon)
            {
                case 1: ql.ThemTaiLieu(); break;
                case 2: ql.HienThiTatCa(); break;
                case 3: ql.TimKiemTheoMa(); break;
                case 4: return;
            }
        }
    }
}

