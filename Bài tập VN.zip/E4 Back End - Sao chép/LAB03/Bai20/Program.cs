﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        QLHoiVien ql = new QLHoiVien();

        while (true)
        {
            Console.WriteLine("\n===== MENU =====");
            Console.WriteLine("1. Nhập danh sách hội viên");
            Console.WriteLine("2. Tìm hội viên có ngày cưới 11/11/2011");
            Console.WriteLine("3. Hiển thị hội viên có người yêu nhưng chưa cưới");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn: ");
            string chon = Console.ReadLine();

            switch (chon)
            {
                case "1":
                    ql.Nhap();
                    break;
                case "2":
                    ql.TimNgayCuoi();
                    break;
                case "3":
                    ql.HienThiCoNguoiYeuChuaCuoi();
                    break;
                case "0":
                    return;
                default:
                    Console.WriteLine("Chọn không hợp lệ.");
                    break;
            }
        }
    }
}
