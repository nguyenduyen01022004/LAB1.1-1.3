﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Collections.Generic;

public class QLHocSinh
{
    private List<HocSinh> danhSach = new List<HocSinh>();

    public void Nhap()
    {
        Console.Write("Nhập số lượng học sinh: ");
        int n = int.Parse(Console.ReadLine());

        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\n--- Nhập học sinh thứ {i + 1} ---");
            Console.Write("Giới tính học sinh (nam/nữ): ");
            string gt = Console.ReadLine().Trim().ToLower();

            HocSinh hs;
            if (gt == "nam")
                hs = new HocSinhNam();
            else
                hs = new HocSinhNu();

            hs.Nhap();
            danhSach.Add(hs);
        }
    }

    public void HienThiNamKyThuatLonHon8()
    {
        Console.WriteLine("\nHọc sinh nam có điểm Kỹ thuật >= 8:");
        foreach (var hs in danhSach)
        {
            if (hs is HocSinhNam nam && nam.DiemKyThuat >= 8)
            {
                nam.Xuat();
                Console.WriteLine("--------------------------");
            }
        }
    }

    public void InNamTruocNuSau()
    {
        Console.WriteLine("\nDanh sách học sinh nam:");
        foreach (var hs in danhSach)
        {
            if (hs is HocSinhNam)
            {
                hs.Xuat();
                Console.WriteLine("--------------------------");
            }
        }

        Console.WriteLine("\nDanh sách học sinh nữ:");
        foreach (var hs in danhSach)
        {
            if (hs is HocSinhNu)
            {
                hs.Xuat();
                Console.WriteLine("--------------------------");
            }
        }
    }
}
