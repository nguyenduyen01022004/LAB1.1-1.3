﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


public class HSHocSinh : Nguoi
{
    public string Lop { get; set; }
    public string KhoaHoc { get; set; }
    public string KyHoc { get; set; }

    public override void Nhap()
    {
        base.Nhap();
        Console.Write("Nhập lớp: ");
        Lop = Console.ReadLine();
        Console.Write("Nhập khoá học: ");
        KhoaHoc = Console.ReadLine();
        Console.Write("Nhập kỳ học: ");
        KyHoc = Console.ReadLine();
    }

    public override void HienThi()
    {
        base.HienThi();
        Console.WriteLine($"Lớp: {Lop}, Khoá học: {KhoaHoc}, Kỳ học: {KyHoc}");
    }
}

public class QuanLyHocSinh
{
    private List<HSHocSinh> danhSach = new List<HSHocSinh>();

    public void NhapDS()
    {
        Console.Write("Nhập số học sinh: ");
        int n = int.Parse(Console.ReadLine());
        for (int i = 0; i < n; i++)
        {
            Console.WriteLine($"\nNhập thông tin học sinh thứ {i + 1}:");
            HSHocSinh hs = new HSHocSinh();
            hs.Nhap();
            danhSach.Add(hs);
        }
    }

    public void HienThiDS()
    {
        Console.WriteLine("\n--- Danh sách học sinh ---");
        foreach (var hs in danhSach)
        {
            hs.HienThi();
            Console.WriteLine("----------------------");
        }
    }

    public void HienThiHocSinhNu1985()
    {
        Console.WriteLine("\n--- Học sinh nữ sinh năm 1985 ---");
        foreach (var hs in danhSach)
        {
            if (hs.GioiTinh.ToLower() == "nữ" && hs.NamSinh == 1985)
            {
                hs.HienThi();
                Console.WriteLine("----------------------");
            }
        }
    }

    public void TimTheoQueQuan(string que)
    {
        Console.WriteLine($"\n--- Học sinh quê ở {que} ---");
        foreach (var hs in danhSach)
        {
            if (hs.QueQuan.ToLower().Contains(que.ToLower()))
            {
                hs.HienThi();
                Console.WriteLine("----------------------");
            }
        }
    }
}

