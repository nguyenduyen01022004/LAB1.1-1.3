﻿using System;

class Program
{
    static void Main()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        TuyenSinh ts = new TuyenSinh();
        int choice;

        do
        {
            Console.WriteLine("\n===== MENU TUYỂN SINH =====");
            Console.WriteLine("1. Thêm thí sinh");
            Console.WriteLine("2. Hiển thị danh sách trúng tuyển");
            Console.WriteLine("3. Tìm thí sinh theo số báo danh");
            Console.WriteLine("4. Hiển thị tất cả thí sinh");
            Console.WriteLine("0. Thoát");
            Console.Write("Chọn: ");
            choice = int.Parse(Console.ReadLine());

            switch (choice)
            {
                case 1: ts.NhapThiSinh(); break;
                case 2: ts.HienThiThiSinhTrungTuyen(); break;
                case 3: ts.TimTheoSoBaoDanh(); break;
                case 4: ts.HienThiTatCa(); break;
                case 0: Console.WriteLine("Thoát chương trình."); break;
                default: Console.WriteLine("Lựa chọn không hợp lệ."); break;
            }
        } while (choice != 0);
    }
}
