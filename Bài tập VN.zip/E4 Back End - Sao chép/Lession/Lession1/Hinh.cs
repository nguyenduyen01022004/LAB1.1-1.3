﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lession1
{
    //Có 5 loại mức độ truy cập trong C#
    //-public
    //-private
    //-protected
    //-internal
    //-protected internal
    //Cú pháp định nghĩa Class
    //  mức-độ-truy-cập class tên-class
    internal class Hinh
    {
        public abstract double chuVi();
        public abstract double dienTich();

    }
}
