﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lession1
{
    internal class HinhVuong : Hinh
    {
        //1. Định nghĩa các thuộc tính của đối tượng hay biến thành viên
        //Cách 1:
        //private double canh;
        //public double Canh
        //{
        //    get { return canh; }
        //    set { canh = value; }
        //}

        //Cách 2:
        public double Canh { get; set; }
        //2. Phương thức khởi tạo
        //2.1 Không có tham số
        public HinhVuong()
        {
            Canh = 0;
        }
        //2.2 Có tham số
        public HinhVuong(double canh)
        {
            this.Canh = canh;
        }

        //3. Các phương thức
        public override double chuVi()
        {
            return Canh * 4;
        }

        public override double dienTich()
        {
            return Canh * Canh;
        }
    }
}
