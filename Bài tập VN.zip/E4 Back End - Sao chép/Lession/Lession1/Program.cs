﻿////1. Khai báo biến
////Cú pháp: kiểu-dữ-liệu tên biến = giá-trị;
//int a = 3;
//float b = 4.333f;
//double PI = 3.14;
//char c = '0';
//string className = "CNTT 17-07";
//bool isStudent = true;
////2. Nhập, xuất dữ liệu
//Console.Write("Thiết kế, Lập trình Back_End");
//Console.WriteLine("CNTT 17-07");
//string name = "Dang Van Thanh";
//Console.WriteLine("Name: " + name);
//Console.WriteLine("Name: {0}", name);
//Console.WriteLine($"Name: {name}");

//Console.Write("Name: ");
//name = Console.ReadLine();//Nhap du lieu 
//Console.WriteLine($"Your name: {name}");

//Console.Write("Age");
//int age = int.Parse(Console.ReadLine());
//Console.WriteLine($"Your age: {age}");
////3. Cấu trúc rẽ nhánh
////3.1. If esle
//if (age < 18)
//{
//    Console.WriteLine("Reject!");
//}
//else
//{
//    Console.WriteLine("Accept!");
//}
////3.2. Switch case
////4. Vòng lặp
////4.1. for
////4.2. while
////4.3. do..while
////4.4. foreach
//List<string> names = new List<string>
//{
//    "Nguyễn Văn An",
//    "Đăng Quang Huy",
//    "Trần Quốc Tuấn"
//};
//foreach (string item in names)
//{
//    Console.WriteLine(item);
//}
////5. Lập trình hướng đối tượng
//    4 tính chất
//        - Trừu tượng
//        - Đóng gói
//        - Kế thừa
//        - Đa hình
// */
using Lession1;

///*
//Khai báo và khởi tạo đối tượng
//Cú pháp: Tên-lớp tên-đối-tượng = new Constructor();
HinhVuong hinhVuong = new HinhVuong(5);
try
{
    Console.Write("Nhap canh cua hinh vuong");
    hinhVuong.Canh = double.Parse(Console.ReadLine());
    if(hinhVuong.Canh <= 0)
    {
        //Tung ngoại lệ cưỡng bức
        throw new Exception("Khong nhap duoc so am");
        //Tự định nghĩa ngoại lệ
    }
}
catch (Exception ex)
{
    //Khối lệnh xử lý ngoại lệ
    Console.WriteLine("Nhập sai!"+ ex.Message);
    hinhVuong.Canh = 1;
}
finally
{
    //Khối lệnh luôn được thực thi
    Console.WriteLine($"Canh: {hinhVuong.Canh}");
    Console.WriteLine($"Chu vi: {hinhVuong.chuVi()}");
    Console.WriteLine($"Dien tich: {hinhVuong.dienTich()}");
}
